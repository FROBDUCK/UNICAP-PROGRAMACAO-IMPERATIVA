package br.unicap.progImp.exercicio01;

import java.util.Scanner;

public class Question04 {

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int n = s.nextInt();

        int[][] matriz = new int[n][n];

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (i < j) {
                    matriz[i][j] = 2 * i + 7 * j - 2;
                } else if (i == j) {
                    matriz[i][j] = 3 * i * i - 1;
                } else {
                    matriz[i][j] = 4 * i * i * i - 5 * j * j + 1;
                }
            }
        }

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                System.out.print(matriz[i][j]);
                if (j < n - 1) {
                    System.out.print(".0, ");
                }
            }
            System.out.println();
        }

        s.close();
    }
}


