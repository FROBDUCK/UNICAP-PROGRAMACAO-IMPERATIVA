package br.unicap.progImp.exercicio01;

import java.util.Scanner;

public class Question03 {

    public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int[][] matriz = new int[10][10];

        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                matriz[i][j] = s.nextInt();
            }
        }

        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                System.out.print(matriz[i][j] + " ");
            }
            System.out.println();
        }

        int ml5 = matriz[5][0];
        for (int j = 1; j < 10; j++) {
            if (matriz[5][j] > ml5) {
                ml5 = matriz[5][j];
            }
        }
        System.out.println(ml5);

        int mc7 = matriz[0][7];
        for (int i = 1; i < 10; i++) {
            if (matriz[i][7] > mc7) {
                mc7 = matriz[i][7];
            }
        }
        System.out.println(mc7);

        s.close();
    }
}


