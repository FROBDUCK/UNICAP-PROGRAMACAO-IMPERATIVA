package br.unicap.progImp.exercicio01;

import org.junit.jupiter.api.Test;

public class TestQuestion04 extends TestBase{

    @Test
    void test01() {
        testInputOutput("3", "-1.0, 5.0, 12.0\n5.0, 2.0, 14.0\n33.0, 28.0, 11.0\n");
    }

    @Test
    void test02() {
        testInputOutput("5", "-1.0, 5.0, 12.0, 19.0, 26.0\n5.0, 2.0, 14.0, 21.0, 28.0\n33.0, 28.0, 11.0, 23.0, 30.0\n109.0, 104.0, 89.0, 26.0, 32.0\n257.0, 252.0, 237.0, 212.0, 47.0\n");
    }

    @Test
    void test03() {
        testInputOutput("7","-1.0, 5.0, 12.0, 19.0, 26.0, 33.0, 40.0\n5.0, 2.0, 14.0, 21.0, 28.0, 35.0, 42.0\n33.0, 28.0, 11.0, 23.0, 30.0, 37.0, 44.0\n109.0, 104.0, 89.0, 26.0, 32.0, 39.0, 46.0\n257.0, 252.0, 237.0, 212.0, 47.0, 41.0, 48.0\n501.0, 496.0, 481.0, 456.0, 421.0, 74.0, 50.0\n865.0, 860.0, 845.0, 820.0, 785.0, 740.0, 107.0\n");
    }

    @Override
    public void main() {
        Question04.main(null);
    }
}
