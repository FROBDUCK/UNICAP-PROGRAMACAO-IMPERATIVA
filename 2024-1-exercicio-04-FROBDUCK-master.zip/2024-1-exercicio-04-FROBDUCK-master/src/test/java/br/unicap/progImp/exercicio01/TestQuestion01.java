package br.unicap.progImp.exercicio01;

import org.junit.jupiter.api.Test;
 

class TestQuestion01 extends TestBase{

  @Test
  void test01() {
    testInputOutput("2\n3\n5\n7\n8", "3 5 \n7 8 \n");
  }

  @Test
  void test02() {
    testInputOutput("4\n3\n5\n7\n8\n2\n5\n12\n66\n7\n4\n5\n5\n3\n2\n6\n0", "3 5 7 8 \n2 5 12 66 \n7 4 5 5 \n3 2 6 0 \n");
  }

  @Override
  public void main() {
    Question01.main(null);
  }

}
