package br.unicap.progImp.exercicio01;

import org.junit.jupiter.api.Test;

class TestQuestion02 extends TestBase{

  @Test
  void test01() {
    testInputOutput("2",
    "0 0 \n0 1 \n");
  }

  @Test
  void test02() {
    testInputOutput("4", "0 0 0 0 \n0 1 2 3 \n0 2 4 6 \n0 3 6 9 \n");
  }

  @Test
  void test03() {
    testInputOutput("8", "0 0 0 0 0 0 0 0 \n"+ //
    "0 1 2 3 4 5 6 7 \n"+ //
    "0 2 4 6 8 10 12 14 \n"+ //
    "0 3 6 9 12 15 18 21 \n"+ //
    "0 4 8 12 16 20 24 28 \n"+ //
    "0 5 10 15 20 25 30 35 \n"+ //
    "0 6 12 18 24 30 36 42 \n"+ //
    "0 7 14 21 28 35 42 49 \n");
  }

  @Override
  public void main() {
    Question02.main(null);
  }

  
}
