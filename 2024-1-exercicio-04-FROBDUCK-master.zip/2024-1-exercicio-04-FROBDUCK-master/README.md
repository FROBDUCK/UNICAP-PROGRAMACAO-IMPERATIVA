# Lista de Exercícios
<img src="assets/images/Unicap_Icam_Tech-01.png" alt="drawing" width="200"/>

## Identificação
**Professor**: Daniel Bezerra

**Disciplina**: Programação Imperativa

**Atividade**: Exercício 4 - 10/04/24

## Instruções 
> 1. Sua implementação deve estar dentro da pasta src/**main**/java 
> 2. Não modifique nenhum código dentro da pasta src/**test**/java.
> 3. A submissão **não deve ser feita após o prazo** (nem 1 minuto a mais)
> 4. Todo código a ser implementado deve ser feito em Java
> 5. A entrega será exclusivamente feita através do repositório do github dado através do link da atividade

## Descrição da Atividade
### Questão 01

Criar um programa, em java, que recebe N números inteiros e imprime uma matriz quadrada.

**Input**

Um número N

N números inteiros

**Output**

A matriz quadrada separada por espaços, incluindo um espaço no último número da linha da matriz.

|**Input Samples**            |**Output Samples**|
|-------------------------------|------------------------------|
|  2</br>2</br>9</br>8</br>7      | 2 9&nbsp;<br>8 7&nbsp;</br>  |
|  3</br>1</br>2</br>3</br>4</br>5</br>6</br>7</br>8</br>9      | 1 2 3&nbsp;<br>4 5 6&nbsp;<br>7 8 9&nbsp;</br>  |

### Questão 02

Crie um programa, em java, que lê um número N e imprima um matriz NxN na qual os valores dos elementos é igual ao produto das respectivas posições (linha i x coluna j)

### Input do programa

Um inteiro N

### Output do programa

A matriz preenchida

|**Input Samples**|**Output Samples**|
|-----------------|------------------|
| 2 | 0 0&nbsp;</br>0 1&nbsp; |
| 4 | 0 0 0 0&nbsp;</br>0 1 2 3&nbsp;</br>0 2 4 6&nbsp;</br>0 3 6 9&nbsp; |

### Questão 03

Crie um programa que leia uma matriz 10x10. Após a leitura da matriz, imprima toda a matriz e escreva o maior número da linha 5 e o maior número da coluna 7 (considerando que linhas e colunas comecem no 0).

### Input do programa

Uma matriz 10x10

### Output do programa

A matriz

O maior número da linha 5

O maior número da coluna 7

|**Input Samples**|**Output Samples**|
|-----------------|------------------|
|8 8 9 9 8 1 2 0 8 1</br>2 4 2 1 7 0 9 7 3 0</br>5 9 2 5 1 7 9 1 1 3</br>9 2 6 9 7 0 1 5 4 0</br>3 1 6 8 6 7 5 2 3 0</br>8 9 2 6 5 0 5 8 1 1</br>8 4 1 4 7 8 0 1 9 9</br>9 1 5 4 5 2 3 2 0 9</br>1 4 3 3 3 6 7 4 1 3</br>4 3 6 7 7 2 0 7 3 7 | 8 8 9 9 8 1 2 0 8 1 </br>2 4 2 1 7 0 9 9 3 0 </br>5 9 2 5 1 7 9 1 1 3 </br>9 2 6 9 7 0 1 5 4 0 </br>3 1 6 8 6 7 5 2 3 0 </br>8 9 2 6 5 0 5 8 1 1 </br>8 4 1 4 7 8 0 1 9 9 </br>9 1 5 4 5 2 3 2 0 9 </br>1 4 3 3 3 6 7 9 1 3 </br>4 3 6 7 7 2 0 7 3 7 </br>9</br>8|

### Question 04

Gerar e imprimir uma matriz de tamanho N x N, onde seus elementos sao da forma:

```
M[i][j] = 2*i + 7*j − 2, se i < j;
M[i][j] = 3*i² − 1, se i = j;
M[i][j] = 4*i³ − 5*j² + 1, se i > j.
```

### Input do programa

Um inteiro N

### Output do programa

A Matriz gerada com cada elemento separado por vírgula seguido de um espaço, exceto nos últimos elementos das linhas, que não tem vírgulas ou espaços após eles. 

|**Imput Samples**|**Output Samples**|
|-----------------|------------------|
| 3 | -1.0, 5.0, 12.0</br>5.0, 2.0, 14.0</br>33.0, 28.0, 11.0 |
| 5 | -1.0, 5.0, 12.0, 19.0, 26.0</br>5.0, 2.0, 14.0, 21.0, 28.0</br>33.0, 28.0, 11.0, 23.0, 30.0</br>109.0, 104.0, 89.0, 26.0, 32.0</br>257.0, 252.0, 237.0, 212.0, 47.0</br> |

