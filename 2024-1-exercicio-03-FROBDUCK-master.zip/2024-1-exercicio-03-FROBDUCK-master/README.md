[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/XyU2AkNh)
# Lista de Exercícios
<img src="assets/images/Unicap_Icam_Tech-01.png" alt="drawing" width="200"/>

## Identificação
**Professor**: Daniel Bezerra

**Disciplina**: Programação Imperativa

**Atividade**: Exercício 3 - 27/03/24

## Instruções 
> 1. Sua implementação deve estar dentro da pasta src/**main**/java 
> 2. Não modifique nenhum código dentro da pasta src/**test**/java.
> 3. A submissão **não deve ser feita após o prazo** (nem 1 minuto a mais)
> 4. Todo código a ser implementado deve ser feito em Java
> 5. A entrega será exclusivamente feita através do repositório do github dado através do link da atividade

## Descrição da Atividade
### Questão 01

Criar um vetor A com 5 elementos inteiros. Construir um vetor B de mesmo tipo e tamanho e com os elementos do vetor A multiplicados por 2, ou seja: B[i] = A[i] * 2.

**Input**

5 números inteiros.

**Output**

Os dois vetores impressos

|**Imput Samples**            |**Output Samples**|
|-------------------------------|------------------------------|
|  3</br>2</br>9</br>8</br>7      | A[0]: 3, B[0]: 6</br>A[1]: 2, B[1]: 4</br>A[2]: 9, B[2]: 18</br>A[3]: 8, B[3]: 16</br>A[4]: 7, B[4]: 14</br>|

### Questão 02

Criar dois vetores A e B cada um com 10 elementos inteiros. Construir um vetor C, onde cada elemento de C é a multiplicação dos respectivos elementos em A e B, ou seja: C[i] = A[i] * B[i].

### Input do programa

20 números inteiros. Os primeiros 10 são elementos de A, os 10 seguintes são elementos de B.

### Output do programa

O vetor C impresso.

|**Imput Samples**|**Output Samples**|
|-----------------|------------------|
| 1</br>2</br>3</br>4</br>5</br>6</br>7</br>8</br>9</br>10</br>10</br>9</br>8</br>7</br>6</br>5</br>4</br>3</br>2</br>1 | 10</br>18</br>24</br>28</br>30</br>30</br>28</br>24</br>18</br>10 |

### Question 03

Crie um programa que busque, dentre 10 valores, quais estão entre um limite mínimo e um limite máximo. O programa recebe 12 números inteiros, onde os dois primeiros números representam um valor mínimo e um valor máximo. Os próximos 10 números são armazenados e comparados com os dois limites.

### Input do programa

12 números inteiros

### Output do programa

Todos os números que estão entre o limite inferior e limite superior

|**Imput Samples**|**Output Samples**|
|-----------------|------------------|
| 10</br>20</br>1</br>7</br>55</br>10</br>4</br>20</br>0</br>6</br>14</br>7 | 10</br>20</br>14 |
| 1</br>5</br>6</br>7</br>55</br>10</br>9</br>20</br>0</br>6</br>14</br>7 | nulo |


### Question 04

Leia um conjunto de alunos, que estão estudando durante a páscoa, cada uma com o nome e a nota. Em seguida exiba o nome dos alunos que possuem a nota maior ou igual que a média da turma.

### Input do programa

Um valor n que representa a quantidade de alunos da turma
n nomes de alunos
n notas (double) dos alunos

### Output do programa

Os nomes dos alunos que tem a nota maior que a media

|**Imput Samples**|**Output Samples**|
|-----------------|------------------|
| 5</br>douglas</br>saira</br>emmanuel</br>enio</br>joyce</br>8</br>5.5</br>6.5</br>4</br>7.5 | douglas</br>emmanuel</br>enio</br>joyce |
| 3</br>yasmin</br>felipe</br>agostinho</br>7</br>7</br>7.5 | agostinho | 