package br.unicap.progImp.exercicio01;

import java.util.Scanner;

public class Question02 {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int[] A = new int[10];
        int[] B = new int[10];
        
        for (int i = 0; i < 10; i++) {
            A[i] = s.nextInt();
        }
        
        for (int i = 0; i < 10; i++) {
            B[i] = s.nextInt();
        }
        
        
        int[] C = new int[10];
        for (int i = 0; i < 10; i++) {
            C[i] = A[i] * B[i];
        }
        
        for (int i = 0; i < 10; i++) {
            System.out.println(C[i]);
        }
        
        s.close();
		
	}

}