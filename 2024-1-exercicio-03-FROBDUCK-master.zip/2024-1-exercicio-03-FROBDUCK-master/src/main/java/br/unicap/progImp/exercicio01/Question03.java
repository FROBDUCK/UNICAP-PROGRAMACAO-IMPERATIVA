package br.unicap.progImp.exercicio01;

import java.util.Scanner;

public class Question03 {

    public static void main(String[] args) {  
        Scanner s = new Scanner(System.in);

        int limiteMin = s.nextInt();
        int limiteMax = s.nextInt();
        StringBuilder output = new StringBuilder();
    
        for (int i = 0; i < 10; i++) {
            int numero = s.nextInt();
            if (numero >= limiteMin && numero <= limiteMax) {
                if (output.length() > 0) {
                    output.append("\n");
                }
                output.append(numero);
            }
        }
        if (output.length() > 0) {
            System.out.println(output);
        } else {
            System.out.println("nulo");
        }
        
        s.close();
    }

}
