package br.unicap.progImp.exercicio01;

import java.util.Locale;
import java.util.Scanner;

public class Question04 {

    public static void main(String[] args) {
        //useLocale garante que o scanner leia numeros
        //naturais com ponto, formato US (7.5) e nao
        //com virgula, formato BR (7,5)
        Scanner s = new Scanner(System.in).useLocale(Locale.US);
        

    }
}
