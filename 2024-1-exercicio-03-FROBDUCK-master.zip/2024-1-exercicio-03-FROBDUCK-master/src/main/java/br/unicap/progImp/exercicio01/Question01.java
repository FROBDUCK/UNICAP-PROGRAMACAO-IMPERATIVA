package br.unicap.progImp.exercicio01;

import java.util.Scanner;

public class Question01 {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
        int[] A = new int[5];
        

        for (int i = 0; i < A.length; i++) {
            A[i] = s.nextInt();
        }
        
		int[] B = new int[5];
        for (int i = 0; i < A.length; i++) {
            B[i] = A[i] * 2;
        }
        
        for (int i = 0; i < A.length; i++) {
            System.out.println("A[" + i + "]: " + A[i] + ", B[" + i + "]: " + B[i]);
        }
        
        s.close();

		
	}
}