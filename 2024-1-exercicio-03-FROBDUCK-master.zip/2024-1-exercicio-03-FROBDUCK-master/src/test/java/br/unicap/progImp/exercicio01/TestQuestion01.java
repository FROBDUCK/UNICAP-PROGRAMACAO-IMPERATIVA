package br.unicap.progImp.exercicio01;

import org.junit.jupiter.api.Test;
 

class TestQuestion01 extends TestBase{

  @Test
  void test01() {
    testInputOutput("3\n2\n9\n8\n7", "A[0]: 3, B[0]: 6\n" + //
        "A[1]: 2, B[1]: 4\n" + //
        "A[2]: 9, B[2]: 18\n" + //
        "A[3]: 8, B[3]: 16\n" + //
        "A[4]: 7, B[4]: 14\n");
  }

  @Test
  void test02() {
    testInputOutput("10\n3\n20\n22\n11", "A[0]: 10, B[0]: 20\n" + //
        "A[1]: 3, B[1]: 6\n" + //
        "A[2]: 20, B[2]: 40\n" + //
        "A[3]: 22, B[3]: 44\n" + //
        "A[4]: 11, B[4]: 22\n");
  }

  @Test
  void test03() {
    testInputOutput("0\n-3\n7\n-1\n3", "A[0]: 0, B[0]: 0\n" + //
        "A[1]: -3, B[1]: -6\n" + //
        "A[2]: 7, B[2]: 14\n" + //
        "A[3]: -1, B[3]: -2\n" + //
        "A[4]: 3, B[4]: 6\n");
  }

  
  

  @Override
  public void main() {
    Question01.main(null);
  }

}
