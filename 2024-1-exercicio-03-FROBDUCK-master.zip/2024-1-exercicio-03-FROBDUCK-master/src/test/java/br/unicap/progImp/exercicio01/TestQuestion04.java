package br.unicap.progImp.exercicio01;

import org.junit.jupiter.api.Test;

public class TestQuestion04 extends TestBase{

    @Test
    void test01() {
        testInputOutput("5\ndouglas\nsaira\nemmanuel\nenio\njoyce\n8\n5.5\n6.5\n4\n7.5","douglas\nemmanuel\njoyce\n");
    }

    @Test
    void test02() {
        testInputOutput("10\nfulano\nbeltrano\ncicrano\njose\nmaria\njoao\nmarcos\ndaniel\ncarlos\nmarta\n5\n5.5\n8\n4.5\n7\n3\n10\n4\n3\n10","cicrano\n" + //
                "maria\n" + //
                "marcos\n" + //
                "marta\n");
    }

    @Test
    void test03() {
        testInputOutput("3\nfulano\nbeltrano\ncicrano\n7\n7\n7","fulano\nbeltrano\ncicrano\n");
    }

    @Override
    public void main() {
        Question04.main(null);
    }
}
