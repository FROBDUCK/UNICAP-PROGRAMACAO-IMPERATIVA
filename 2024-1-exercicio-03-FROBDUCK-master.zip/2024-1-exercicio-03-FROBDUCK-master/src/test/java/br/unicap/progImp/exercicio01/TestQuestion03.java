package br.unicap.progImp.exercicio01;

import org.junit.jupiter.api.Test;

class TestQuestion03 extends TestBase{

    @Test
    void test01() {
      testInputOutput("10\n" + //
          "20\n" + //
          "1\n" + //
          "7\n" + //
          "55\n" + //
          "10\n" + //
          "4\n" + //
          "20\n" + //
          "0\n" + //
          "6\n" + //
          "14\n" + //
          "7", "10\n20\n14\n");
    }
  
    @Test
    void test02() {
      testInputOutput("-5\n" + //
          "5\n" + //
          "0\n" + //
          "3\n" + //
          "-2\n" + //
          "10\n" + //
          "4\n" + //
          "20\n" + //
          "0\n" + //
          "6\n" + //
          "14\n" + //
          "7", "0\n3\n-2\n4\n0\n");
    }
  
    @Test
    void test03() {
      testInputOutput("2\n" + //
          "10\n" + //
          "20\n" + //
          "13\n" + //
          "12\n" + //
          "11\n" + //
          "14\n" + //
          "20\n" + //
          "120\n" + //
          "36\n" + //
          "14\n" + //
          "57", "nulo\n");
    }
  
    @Override
    public void main() {
      Question03.main(null);
    }
  
  }
