package br.unicap.progImp.exercicio01;

import org.junit.jupiter.api.Test;

class TestQuestion02 extends TestBase{

  @Test
  void test01() {
    testInputOutput("1\n" + //
        "2\n" + //
        "3\n" + //
        "4\n" + //
        "5\n" + //
        "6\n" + //
        "7\n" + //
        "8\n" + //
        "9\n" + //
        "10\n" + //
        "10\n" + //
        "9\n" + //
        "8\n" + //
        "7\n" + //
        "6\n" + //
        "5\n" + //
        "4\n" + //
        "3\n" + //
        "2\n" + //
        "1", "10\n" + //
            "18\n" + //
            "24\n" + //
            "28\n" + //
            "30\n" + //
            "30\n" + //
            "28\n" + //
            "24\n" + //
            "18\n" + //
            "10\n");
  }

  @Test
  void test02() {
    testInputOutput("3\n" + //
        "7\n" + //
        "4\n" + //
        "0\n" + //
        "0\n" + //
        "1\n" + //
        "3\n" + //
        "13\n" + //
        "4\n" + //
        "1\n" + //
        "7\n" + //
        "45\n" + //
        "23\n" + //
        "8\n" + //
        "3\n" + //
        "9\n" + //
        "0\n" + //
        "0\n" + //
        "3\n" + //
        "2", "21\n315\n92\n0\n0\n9\n0\n0\n12\n2\n");
  }

  @Test
  void test03() {
    testInputOutput("-1\n" + //
        "-2\n" + //
        "-3\n" + //
        "4\n" + //
        "5\n" + //
        "6\n" + //
        "7\n" + //
        "8\n" + //
        "9\n" + //
        "10\n" + //
        "10\n" + //
        "5\n" + //
        "3\n" + //
        "7\n" + //
        "6\n" + //
        "5\n" + //
        "4\n" + //
        "3\n" + //
        "2\n" + //
        "1", "-10\n-10\n-9\n28\n30\n30\n28\n24\n18\n10\n");
  }

  @Override
  public void main() {
    Question02.main(null);
  }

  
}
